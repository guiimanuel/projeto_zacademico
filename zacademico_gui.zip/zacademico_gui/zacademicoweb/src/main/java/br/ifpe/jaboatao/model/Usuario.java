package br.ifpe.jaboatao.model;

public abstract class Usuario{
    private String nome;
    private String cpf;
    private int idade;
    private String email_pessoal;
    private String email_institucional;
    private String senha;

    public Usuario(String nome, String cpf, String email_pessoal){
        this.nome = nome;
        this.cpf = cpf;
        this.email_pessoal= email_pessoal;
    }
    public String getNome(){
        return this.nome;

    }
    public void setNome(String nome){
        this.nome = nome;
    }
     public String getCpf(){
        return this.cpf;

    }
    public void setCpf(String cpf){
        if(!cpf.isBlank()){
   		 this.cpf = cpf;
        }
    }
     public int getIdade(){
        return this.idade;
    }
    public void setIdade(int idade){
        if(idade >= 0){
   		 this.idade = idade;
   	 }
    }
    public String getEmail_pessoal(){
        return this.email_pessoal;
    }
     public void setEmail_pessoal(String email_pessoal){
        if(!email_pessoal.isBlank()){
   		 this.email_pessoal = email_pessoal;
   	 }
    }
    public String getEmail_institucional(){
        return this.email_institucional;
    }
     public void setEmail_institucional(String email_institucional){
        if(!email_institucional.isBlank()){
   		 this.email_institucional = email_institucional;
   	 }
    }
    public String getSenha(){
        return this.senha;
    }

    public void setSenha(String senha) {
        if(!senha.isBlank()){
   		 this.senha = senha;
   	 }
    }
    public abstract void imprimeInfo();
}

