package br.ifpe.jaboatao.model;

//import java.util.List;
//import view.ViewCadastroAluno;

public class Principal {
	public static void main(String[] args) {
  	 
   		//ViewCadastroAluno viewCadAluno = new ViewCadastroAluno();
	}
}
