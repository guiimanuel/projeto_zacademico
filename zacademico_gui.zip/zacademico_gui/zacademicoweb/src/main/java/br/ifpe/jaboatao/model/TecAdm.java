package br.ifpe.jaboatao.model;

public class TecAdm extends Usuario{
    private int siape;
    private String especialidade;
    private String nivel_instrucao;

    public TecAdm(String nome, String cpf, String email_pessoal, int siape, String especialidade, String nivel_instrucao){
   	 super(nome, cpf, email_pessoal);
   	 this.siape = siape;
   	 this.especialidade = especialidade;
   	 this.nivel_instrucao = nivel_instrucao;
    }

    public int getSiape(){
   	 return this.siape;
    }
    public void setSiape(int siape){
   	 if(siape != 0){
   		 this.siape = siape;
   	 }
    }
    
    public String getEspecialidade(){
   	 return this.especialidade;
    }
    public void setEspecialidade(String especialidade){
   	 if(!especialidade.isBlank()){
   		 this.especialidade = especialidade;
   	 }
    }

    public String getNivel_instrucao(){
   	 return this.nivel_instrucao;
    }
    public void setNivel_instrucao(String nivel_instrucao){
   	 if(!nivel_instrucao.isBlank()){
   		 this.nivel_instrucao = nivel_instrucao;
   	 }
    }

    @Override
    public void imprimeInfo(){
   	 System.out.println(getNome());
   	 System.out.println(getCpf());
   	 System.out.println(getEmail_pessoal());
   	 System.out.println(this.siape);
   	 System.out.println(this.especialidade);
   	 System.out.println(this.nivel_instrucao);
    }

}
