package br.ifpe.jaboatao.model;
import java.util.List;

public class Turma {
	private String nome;
	private String sala;
	private String horario_inicio;
	private String horario_fim;
	private Disciplina disciplinas;
	private List <Professor> professores;


	public Turma(String nome, String sala, String horario_inicio, String horario_fim, Disciplina disciplinas, List<Professor> professores) {
    	this.nome = nome;
    	this.horario_inicio = horario_inicio;
    	this.horario_fim = horario_fim;
    	this.disciplinas = disciplinas;
    	this.professores = professores;
	}


	public String getNome() {
    	return this.nome;
	}

	public void setNome(String nome) {
    	this.nome = nome;
	}

	public String getSala() {
    	return this.sala;
	}

	public void setSala(String sala) {
    	this.sala = sala;
	}

	public String getHorario_inicio() {
    	return this.horario_inicio;
	}

	public void setHorario_inicio(String horario_inicio) {
    	this.horario_inicio = horario_inicio;
	}

	public String getHorario_fim() {
    	return this.horario_fim;
	}

	public void setHorario_fim(String horario_fim) {
    	this.horario_fim = horario_fim;
	}

	public Disciplina getDisciplinas() {
    	return this.disciplinas;
	}

	public void setDisciplinas(Disciplina disciplinas) {
    	this.disciplinas = disciplinas;
	}

	public List<Professor> getProfessores() {
    	return this.professores;
	}

	public void setProfessores(List<Professor> professores) {
    	this.professores = professores;
	}
    
}
