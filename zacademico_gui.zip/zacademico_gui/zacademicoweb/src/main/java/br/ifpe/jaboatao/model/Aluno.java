package br.ifpe.jaboatao.model;

public class Aluno extends Usuario{
    private String matricula;
    private Escola escolaOrigem;

    public Aluno(String nome, String cpf, int idade, String email_pessoal, String matricula){
        super(nome,cpf,email_pessoal);
        this.matricula = matricula;
    }

    public String getMatricula() {
        return this.matricula;
    }

    public void setMatricula(String matricula) {
        if(!matricula.isBlank()){
  		  this.matricula = matricula;
  	  }
    }
    public Escola getEscolaOrigem() {
        return this.escolaOrigem;
    }

    public void setEscolaOrigem(Escola escolaOrigem) {
        this.escolaOrigem = escolaOrigem;
    }

    @Override
    public void imprimeInfo(){
   	 System.out.println(getNome());
   	 System.out.println(getCpf());
   	 System.out.println(getEmail_pessoal());
   	 System.out.println(this.matricula);
    }
}
