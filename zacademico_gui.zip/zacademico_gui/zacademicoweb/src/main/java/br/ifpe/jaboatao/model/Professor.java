package br.ifpe.jaboatao.model;

public class Professor extends Usuario {
    private int siape;
    private String area_formacao;
    private String nivel_instrucao;
    
    public Professor (String nome, String cpf, String email_pessoal, int siape, String area_formacao, String nivel_instrucao){
   	 super(nome, cpf, email_pessoal);
   	 //super serve pra pegar o método da superclasse
   	 this.siape = siape;
   	 this.area_formacao = area_formacao;
   	 this.nivel_instrucao = area_formacao;
    }

    public int getSiape(){
   	 return this.siape;
    }
    public void setSiape(int siape){
   	 if(siape >= 0){
   		 this.siape = siape;
   	 }
    }
    public String getAreaFormacao(){
   	 return this.area_formacao;
    }
    public void setAreaFormacao(String area_formacao){
   	 if(!area_formacao.isBlank()){
   		 this.area_formacao = area_formacao;
   	 }
    }
    public String getNivelInstrucao(){
   	 return this.nivel_instrucao;
    }
    public void setNivelInstrucao(String nivel_instrucao){
   	 if(!nivel_instrucao.isBlank()){
   		 this.nivel_instrucao = nivel_instrucao;
   	 }
    }

    @Override
    public void imprimeInfo(){
   	 System.out.println(getNome());
   	 System.out.println(getCpf());
   	 System.out.println(getEmail_pessoal());
   	 System.out.println(this.siape);
    }

}