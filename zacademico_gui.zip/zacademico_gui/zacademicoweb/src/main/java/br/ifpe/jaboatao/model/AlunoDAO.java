package br.ifpe.jaboatao.model;
import org.springframework.jdbc.core.simple.JdbcClient;

public class AlunoDAO {
    private final JdbcClient jdbcClient;

    public AlunoDAO(JdbcClient jdbcClient) {
        this.jdbcClient = jdbcClient;
    };

    public Integer create(Aluno aluno){
        String sql_insert = "Insert into Aluno (nome, cpf, idade, email_pessoal, matricula) values(:nome, :cpf, :idade, :matricula)";

        return jdbcClient.sql(sql_insert).param("nome", aluno.getNome()).param("cpf", aluno.getCpf()).param("idade", aluno.getIdade()).param("email_pessoal", aluno.getEmail_pessoal()).param("matricula", aluno.getMatricula()).update();
    }
}