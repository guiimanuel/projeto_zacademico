package br.ifpe.jaboatao.model;
import java.util.List;

public class Disciplina {
	private String nome;
	private int ch_total;
	private String tipo;
	private List <Professor> professores;


	public String getNome() {
    	return this.nome;
	}

	public void setNome(String nome) {
    	this.nome = nome;
	}

	public int getCh_total() {
    	return this.ch_total;
	}

	public void setCh_total(int ch_total) {
    	this.ch_total = ch_total;
	}

	public String getTipo() {
    	return this.tipo;
	}

	public void setTipo(String tipo) {
    	this.tipo = tipo;
	}

	public List<Professor> getProfessores() {
    	return this.professores;
	}

	public void setProfessores(List<Professor> professores) {
    	this.professores = professores;
	}

}
