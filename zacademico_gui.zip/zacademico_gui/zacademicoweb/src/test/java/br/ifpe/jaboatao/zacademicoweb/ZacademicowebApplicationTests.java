package br.ifpe.jaboatao.zacademicoweb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZacademicowebApplicationTests {

	@Test
	void contextLoads() {
	}

}
